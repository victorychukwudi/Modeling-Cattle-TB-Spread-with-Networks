####move to list
# Example data
data <- data.frame(
  move_from_id = c(88555, 164789, 124263, 166030, 125272, 67710, 169400, 148460, 76941, 128252),
  move_to_id = c(148790, 125789, 68383, 78803, 145810, 34770, 89644, 16169, 57178, 46876),
  cattle = c(1, 1, 3, 1, 1, 1, 3, 6, 1, 1)
)

# Step 1: Choose 10 move_to_id values (these can be chosen manually or randomly)
selected_move_to_ids <- c(148790, 125789, 68383, 78803, 145810, 34770, 89644, 16169, 57178, 46876)

# Step 2: Filter the data to keep only rows where move_to_id matches the selected ones
filtered_data <- data[data$move_to_id %in% selected_move_to_ids, ]

# Step 3: View the filtered data
print(filtered_data)
library(dplyr)
# Example data (replace with your actual dataset)
data <- data.frame(
  move_from_id = c(88555, 164789, 124263, 166030, 125272, 67710, 169400, 148460, 76941, 128252),
  move_to_id = c(148790, 125789, 68383, 78803, 145810, 34770, 89644, 16169, 57178, 46876),
  from_class = c("B", "D", "M", "B", "S", "D", "B", "S", "D", "B"),
  to_class = c("B", "T", "B", "S", "F", "D", "T", "F", "T", "B"),
  cattle = c(1, 1, 3, 1, 1, 1, 3, 6, 1, 1)
)

# Step 1: Extract the first letter of from_class and to_class columns
data$from_group <- substr(data$from_class, 1, 1)
data$to_group <- substr(data$to_class, 1, 1)

# Step 2: Map the first letter to the 5 main groups
data$from_group <- recode(data$from_group,
                          'B' = 'Beef', 
                          'D' = 'Dairy', 
                          'F' = 'Fattener', 
                          'S' = 'Store', 
                          'T' = 'Trade')

data$to_group <- recode(data$to_group,
                        'B' = 'Beef', 
                        'D' = 'Dairy', 
                        'F' = 'Fattener', 
                        'S' = 'Store', 
                        'T' = 'Trade')

# View the modified data
print(data)
##CREATING A TRADE NETWORK

# Load necessary library
library(igraph)
library(dplyr)

# Create the graph object from filtered data
trade_network <- graph_from_data_frame(filtered_data, directed = TRUE, 
                                       vertices = unique(c(filtered_data$move_from_id, filtered_data$move_to_id)))
print(trade_network)
# Add weights (i.e., number of cattle)
E(trade_network)$weight <- filtered_data$cattle
print(E(trade_network)$weight)
# Create a graph layout with better spacing using the Fruchterman-Reingold algorithm
layout_fr <- layout_with_fr(trade_network)  # Fruchterman-Reingold layout

# Plot the graph with better spacing and show the number of cattle on the edges
plot(trade_network, 
     layout = layout_fr, 
     main = "Cattle Trade Network", 
     vertex.label = V(trade_network)$name,   # Label the farms (nodes)
     vertex.size = 10,                      # Size of the farms (nodes)
     edge.label = E(trade_network)$weight,  # Show the number of cattle on the edges
     edge.label.cex = 1.0,                  # Adjust label size
     edge.color = "gray",                   # Set edge color for better visibility
     vertex.color = "orange",               # Set vertex color
     vertex.frame.color = "black",          # Set vertex frame color
     vertex.label.color = "blue"            # Set label color for visibility
)


### Incorporating the mparse
# Load necessary libraries
library(SimInf)
library(igraph)
library(dplyr)
set.seed(123)

# Create the trade network
trade_network <- graph_from_data_frame(filtered_data, directed = TRUE, 
                                       vertices = unique(c(filtered_data$move_from_id, filtered_data$move_to_id)))
E(trade_network)$weight <- filtered_data$cattle

# Get all unique farm IDs from the network
all_farms <- V(trade_network)$name
cat("Total unique farms:", length(all_farms), "\n")

# Set initial conditions
initial_infected <- "88555"

# Create data frame for initial states
nodes <- data.frame(
  id = all_farms,
  S = ifelse(all_farms == initial_infected, 9, 10),
  I = ifelse(all_farms == initial_infected, 1, 0),
  R = 0
)

# Function to create extTrans events (trade-based spread)
create_network_transmission_events <- function() {
  events_df <- data.frame()
  
  for (i in 1:nrow(filtered_data)) {
    from_farm <- as.character(filtered_data$move_from_id[i])
    to_farm <- as.character(filtered_data$move_to_id[i])
    cattle_moved <- filtered_data$cattle[i]
    
    events_df <- rbind(events_df, data.frame(
      event = "extTrans",
      time = sample(5:25, 1), 
      node = which(all_farms == from_farm),  
      dest = which(all_farms == to_farm),    
      n = 0,
      proportion = 0.2,   # baseline probability of transmission per trade
      select = 1,        
      shift = 0
    ))
  }
  return(events_df)
}

# Create baseline transmission events
transmission_events <- create_network_transmission_events()

# Define E matrix for external transfer
E_matrix <- matrix(c(0, 1, 0), nrow = 3, ncol = 1)  
rownames(E_matrix) <- c("S", "I", "R")
colnames(E_matrix) <- "move_infected"

# Define N matrix for state changes
N_matrix <- matrix(c(0, 0, 0,
                     -1, 1, 0,
                     0, 0, 0),  
                   nrow = 3, ncol = 3, byrow = TRUE)
rownames(N_matrix) <- c("S", "I", "R")

# Define transitions
transitions <- c(
  "S -> beta * S * I / (S + I + R) -> I",  
  "I -> gamma * I -> R"                    
)

compartments <- c("S", "I", "R")

# BASELINE MODEL
model_baseline <- mparse(
  transitions = transitions,
  compartments = compartments,
  events = transmission_events,
  E = E_matrix,
  N = N_matrix,
  gdata = c(beta = 0.08, gamma = 0.04),
  u0 = nodes[, c("S", "I", "R")],
  tspan = 1:50
)
result_baseline <- run(model_baseline)

# POLICY TESTING FUNCTION
test_policy <- function(policy_type, severity = 0.7) {
  
  if (policy_type == "movement_restriction") {
    reduced_events <- transmission_events
    remove_count <- round(nrow(reduced_events) * severity)
    if (remove_count > 0 && remove_count < nrow(reduced_events)) {
      reduced_events <- reduced_events[-sample(1:nrow(reduced_events), remove_count), ]
    }
    gdata <- c(beta = 0.08, gamma = 0.04)
    
  } else if (policy_type == "enhanced_surveillance") {
    reduced_events <- transmission_events
    gdata <- c(beta = 0.08, gamma = 0.04 * (1 + severity))
    
  } else if (policy_type == "biosecurity") {
    reduced_events <- transmission_events
    reduced_events$proportion <- reduced_events$proportion * (1 - severity)  # lower trade risk
    
    gdata <- c(beta = 0.08 * (1 - severity/2), 
               gamma = 0.04 * (1 + severity/2))
  }
  
  policy_model <- mparse(
    transitions = transitions,
    compartments = compartments,
    events = reduced_events,
    E = E_matrix,
    N = N_matrix,
    gdata = gdata,
    u0 = nodes[, c("S", "I", "R")],
    tspan = 1:50
  )
  
  return(run(policy_model))
}

# Test policies
cat("Testing policy interventions...\n")
movement_restriction <- test_policy("movement_restriction", 0.7)
enhanced_surveillance <- test_policy("enhanced_surveillance", 0.7)
biosecurity <- test_policy("biosecurity", 0.7)

# Comparison function
compare_policies <- function(results_list, policy_names) {
  cat("\n=== POLICY COMPARISON ===\n")
  
  for (i in seq_along(results_list)) {
    traj_data <- trajectory(results_list[[i]])
    final_time <- max(traj_data$time)
    
    # Farms infected at final time
    infected_farms <- traj_data[traj_data$time == final_time, ]
    total_infected_farms <- sum(infected_farms$I > 0 | infected_farms$R > 0)
    
    # Peak number of infected farms over time
    farms_infected_time <- aggregate(I ~ time + node, data = traj_data, FUN = function(x) any(x > 0))
    farms_infected_count <- aggregate(I ~ time, data = farms_infected_time, FUN = sum)
    peak_infection <- max(farms_infected_count$I)
    
    total_cases <- sum(infected_farms$R)
    
    cat(sprintf("%s:\n", policy_names[i]))
    cat(sprintf("  Infected farms (final): %d/%d\n", total_infected_farms, length(all_farms)))
    cat(sprintf("  Peak infected farms: %d\n", peak_infection))
    cat(sprintf("  Total cattle infected: %.0f\n", total_cases))
    cat("------------------------\n")
  }
}

policy_results <- list(result_baseline, movement_restriction, enhanced_surveillance, biosecurity)
policy_names <- c("No Intervention", "Movement Restrictions", "Enhanced Surveillance", "Biosecurity Improvement")

compare_policies(policy_results, policy_names)

# Visualization
par(mfrow = c(2, 2), mar = c(4, 4, 3, 1))

plot_policy <- function(result, title) {
  traj <- trajectory(result)
  
  # Count infected farms (I > 0)
  farms_infected_time <- aggregate(I ~ time + node, data = traj, FUN = function(x) any(x > 0))
  farms_infected_count <- aggregate(I ~ time, data = farms_infected_time, FUN = sum)
  
  plot(farms_infected_count$time, farms_infected_count$I, type = "l", 
       col = "red", lwd = 2, ylim = c(0, length(all_farms)),
       xlab = "Time", ylab = "Infected Farms", main = title,
       cex.main = 0.9)
  abline(h = length(all_farms), lty = 3, col = "gray")
}

plot_policy(result_baseline, "No Intervention")
plot_policy(movement_restriction, "Movement Restrictions")
plot_policy(enhanced_surveillance, "Enhanced Surveillance")
plot_policy(biosecurity, "Biosecurity Improvement")

# Transmission events check
cat("\n=== TRANSMISSION EVENTS CREATED ===\n")
cat("Number of transmission events:", nrow(transmission_events), "\n")
print(head(transmission_events))
# --- POLICY EFFECTIVENESS ANALYSIS ---
cat("\n=== POLICY EFFECTIVENESS ANALYSIS ===\n")

# Helper to get metrics for a result
get_metrics <- function(result) {
  traj <- trajectory(result)
  final_time <- max(traj$time)
  final_state <- traj[traj$time == final_time, ]
  
  peak_infection <- max(aggregate(I ~ time, data = traj, FUN = sum)$I)
  total_cases <- sum(final_state$R)
  
  return(list(peak = peak_infection, cases = total_cases))
}

# Get baseline metrics
baseline_metrics <- get_metrics(result_baseline)

# Collect metrics for all policies
metrics <- lapply(policy_results, get_metrics)

# Compute reductions relative to baseline
effectiveness <- data.frame(
  Policy = policy_names,
  Peak_Reduction = sapply(metrics, function(m) 
    round((1 - m$peak / baseline_metrics$peak) * 100, 1)),
  Total_Reduction = sapply(metrics, function(m) 
    round((1 - m$cases / baseline_metrics$cases) * 100, 1))
)

print(effectiveness)

# --- PLOT EFFECTIVENESS ---
library(ggplot2)
library(reshape2)

effectiveness_melt <- melt(effectiveness, id.vars = "Policy",
                           variable.name = "Measure", value.name = "Reduction")

ggplot(effectiveness_melt, aes(x = Policy, y = Reduction, fill = Measure)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  labs(title = "Policy Effectiveness in Reducing Infection",
       y = "Reduction (%)", x = "Policy") +
  theme_minimal(base_size = 14) +
  scale_fill_manual(values = c("Peak_Reduction" = "tomato", 
                               "Total_Reduction" = "steelblue"))
##Centralized Measures
# --- STEP 5: IDENTIFYING KEY FARMS AND CENTRAL NODES ---

library(igraph)

cat("\n=== STEP 5: Key Farms in the Trade Network ===\n")

# Calculate degree centrality (in + out connections)
degree_centrality <- degree(trade_network, mode = "all", normalized = TRUE)

# Calculate betweenness centrality (how often a farm sits on shortest paths)
betweenness_centrality <- betweenness(trade_network, normalized = TRUE)

# Combine results into a data frame
centrality_df <- data.frame(
  Farm = names(degree_centrality),
  Degree = degree_centrality,
  Betweenness = betweenness_centrality
)

# Sort by degree and betweenness to identify key farms
top_degree <- centrality_df[order(-centrality_df$Degree), ][1:10, ]
top_betweenness <- centrality_df[order(-centrality_df$Betweenness), ][1:10, ]

cat("\nTop Farms by Degree Centrality (most connected):\n")
print(top_degree)

cat("\nTop Farms by Betweenness Centrality (critical gateways):\n")
print(top_betweenness)

# --- VISUALIZATION ---
library(ggraph)
library(ggplot2)

# Scale node size by degree centrality for visualization
V(trade_network)$size <- 5 + 15 * degree_centrality
V(trade_network)$color <- ifelse(names(V(trade_network)) %in% top_degree$Farm, "red", "skyblue")

ggraph(trade_network, layout = "fr") +
  geom_edge_link(alpha = 0.3) +
  geom_node_point(aes(size = size, color = color)) +
  geom_node_text(aes(label = name), repel = TRUE, size = 3) +
  scale_color_identity() +
  labs(title = "Trade Network with Key Central Farms Highlighted") +
  theme_void()
# --- VISUALIZATION FIXED ---
library(ggraph)
library(ggplot2)

# Add attributes directly into the igraph object
V(trade_network)$degree <- degree_centrality
V(trade_network)$betweenness <- betweenness_centrality
V(trade_network)$highlight <- ifelse(names(V(trade_network)) %in% top_degree$Farm, "High-degree", "Other")

# Plot trade network
ggraph(trade_network, layout = "fr") +
  geom_edge_link(alpha = 0.3) +
  geom_node_point(aes(size = degree, color = highlight)) +
  geom_node_text(aes(label = name), repel = TRUE, size = 3) +
  scale_color_manual(values = c("High-degree" = "red", "Other" = "skyblue")) +
  labs(title = "Trade Network with Key Central Farms Highlighted",
       subtitle = "Node size = Degree centrality | Red = Top-degree farms") +
  theme_void()

